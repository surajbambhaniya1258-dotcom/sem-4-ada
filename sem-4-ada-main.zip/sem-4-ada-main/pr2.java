import java.util.Scanner;

public class BubbleSort {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements: ");
        int num = sc.nextInt();

        int arr[] = new int[num];

        // Generate random elements (0–99)
        for (int i = 0; i < num; i++) {
            arr[i] = (int) (Math.random() * 100);
        }

        // Print original array
        System.out.println("Original array:");
        for (int i = 0; i < num; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();

        long T1 = System.nanoTime();

        // Bubble Sort
        for (int i = 0; i < num - 1; i++) {
            for (int j = 0; j < num - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Swap
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }

        long T2 = System.nanoTime();

        // Sorted array
        System.out.println("Sorted array:");
        for (int k = 0; k < num; k++) {
            System.out.print(arr[k] + " ");
        }

        System.out.println();
        System.out.println("Execution Time: " + (T2 - T1) + " ns");

        sc.close();
    }
}
